# Trading Alert Agent

**Gmail (IMAP) → Claude API → IBKR auto-execution**

Monitors Verified Investing (Gareth Soloway) email alerts.
Parses with Claude Haiku. Executes on Interactive Brokers.

## What's different from last time

- **No Google Cloud** — uses IMAP + Gmail App Password (like before)
- **No Claude Code** — uses `anthropic` Python package with API key (no OAuth, no localhost redirect)
- **Claude parses** — instead of regex, Claude Haiku extracts structured data
- **Single file** — `bot.py` does everything

## Cybercafé Setup (< 1 hour)

### Step 1: Gmail App Password (2 min)
1. Go to myaccount.google.com/apppasswords
2. Create app password → save the 16-char code

### Step 2: Push to GitHub (5 min)
```bash
git clone <this-repo> && cd trading-agent
# or: git init && git add -A && git commit -m "init"
# then: gh repo create trading-agent --private --push
```

### Step 3: Deploy on Railway (10 min)
1. railway.app → New Project → Deploy from GitHub
2. Set Variables:

| Variable | Value |
|---|---|
| EMAIL_USERNAME | your@gmail.com |
| EMAIL_PASSWORD | xxxx xxxx xxxx xxxx (App Password) |
| ANTHROPIC_API_KEY | sk-ant-api03-... |
| ALERT_SENDER | verifiedinvesting.com |
| PAPER_MODE | true |
| KILL_SWITCH | false |
| MAX_SHARES_PER_TRADE | 500 |
| POLL_INTERVAL_SECONDS | 30 |

3. Deploy → check logs

### Step 4: Test (5 min)
Send yourself an email FROM another account with subject like:
"NEW LONG: AAPL" and body matching the Verified Investing format.
Watch Railway logs to see Claude parse it.

### Step 5: IBKR (later, when ready)
Add IB Gateway container or run locally. Set:
- IB_HOST, IB_PORT=4002, IB_ACCOUNT
- PAPER_MODE=false

## Files
- `bot.py` — main agent (IMAP + Claude + IBKR)
- `test_parser.py` — test Claude parsing offline
- `.env.example` — env var template
- `trades.csv` — auto-created trade log
- `processed_ids.json` — dedup tracker

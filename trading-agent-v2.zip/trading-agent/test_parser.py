"""
Test Claude alert parsing against sample Verified Investing alerts.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python test_parser.py
"""

import os
import json

# Minimal env for import
os.environ.setdefault("EMAIL_USERNAME", "test")
os.environ.setdefault("EMAIL_PASSWORD", "test")
os.environ.setdefault("ANTHROPIC_API_KEY", os.environ.get("ANTHROPIC_API_KEY", ""))

if not os.environ.get("ANTHROPIC_API_KEY"):
    print("ERROR: Set ANTHROPIC_API_KEY environment variable")
    exit(1)

from bot import parse_alert

TESTS = [
    {
        "subject": "REDUCE (COVER): STX",
        "body": "REDUCE (COVER): STX\n\nSide: Short\n\nShares: 100\n\nPrice: $504.11\n\nActivity P&L: $828\n\nNotes: Took off 1/3 to reduce exposure.\n\n👉 See the Smart Money: Stocks & ETFs Dashboard here",
        "expect_action": "REDUCE_SHORT",
        "expect_ibkr": "BUY",
    },
    {
        "subject": "NEW SHORT: TSLA",
        "body": "NEW SHORT: TSLA\n\nSide: Short\n\nShares: 50\n\nPrice: $185.50\n\nActivity P&L: N/A\n\nNotes: Bearish setup on daily chart.",
        "expect_action": "OPEN_SHORT",
        "expect_ibkr": "SELL",
    },
    {
        "subject": "CLOSE (COVER): NVDA",
        "body": "CLOSE (COVER): NVDA\n\nSide: Short\n\nShares: 200\n\nPrice: $130.25\n\nActivity P&L: $1,450\n\nNotes: Taking full profit.",
        "expect_action": "CLOSE_SHORT",
        "expect_ibkr": "BUY",
    },
    {
        "subject": "NEW LONG: AAPL",
        "body": "NEW LONG: AAPL\n\nSide: Long\n\nShares: 100\n\nPrice: $195.30\n\nActivity P&L: N/A\n\nNotes: Breakout above resistance.",
        "expect_action": "OPEN_LONG",
        "expect_ibkr": "BUY",
    },
    {
        "subject": "REDUCE: MSFT",
        "body": "REDUCE: MSFT\n\nSide: Long\n\nShares: 50\n\nPrice: $420.00\n\nActivity P&L: $2,100\n\nNotes: Trimming 1/2 into strength.",
        "expect_action": "REDUCE_LONG",
        "expect_ibkr": "SELL",
    },
    {
        "subject": "ADD: AMZN",
        "body": "ADD: AMZN\n\nSide: Long\n\nShares: 25\n\nPrice: $188.75\n\nActivity P&L: N/A\n\nNotes: Adding on pullback to support.",
        "expect_action": "ADD_LONG",
        "expect_ibkr": "BUY",
    },
]

print("=" * 60)
print("CLAUDE ALERT PARSER TEST")
print("=" * 60)

passed = 0
failed = 0

for i, t in enumerate(TESTS, 1):
    print(f"\nTest {i}: {t['subject']}")
    print("-" * 40)

    result = parse_alert(t["subject"], t["body"])

    action_ok = result.get("action") == t["expect_action"]
    ibkr_ok = result.get("ibkr_action") == t["expect_ibkr"]
    conf_ok = result.get("confidence") != "low"

    ok = action_ok and ibkr_ok and conf_ok

    print(f"  {'✅' if action_ok else '❌'} action:      {result.get('action')} (expect: {t['expect_action']})")
    print(f"  {'✅' if ibkr_ok else '❌'} ibkr_action: {result.get('ibkr_action')} (expect: {t['expect_ibkr']})")
    print(f"  {'✅' if conf_ok else '⚠️'} confidence:  {result.get('confidence')}")
    print(f"     ticker={result.get('ticker')} shares={result.get('shares')} price={result.get('price')}")

    if ok:
        passed += 1
    else:
        failed += 1
        print(f"     FULL: {json.dumps({k:v for k,v in result.items() if k != '_raw_response'})}")

print(f"\n{'=' * 60}")
print(f"Results: {passed} passed, {failed} failed out of {len(TESTS)}")
print(f"{'✅ ALL PASSED' if failed == 0 else '❌ SOME FAILED'}")
